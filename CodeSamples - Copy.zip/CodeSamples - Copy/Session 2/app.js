// Build Webserver with Express

// const express = require('express');
// const app=express();

// //The first argument is the path or URL. The second argument is a callback function
// //app.post()
// //app.put()
// //app.delete()

// //we want o implement couple of endpoint that returns some result.

// app.get('/',(req,res) => {
// 	res.send('Hello World');
// });

// app.get('/api/books',(req,res) => {
// 	res.send(["Book 1","Book 2","Book3"]);
// });

// const books =[
// 	{id:1, name: "book 1"},
// 	{id:2, name: "book 2"},
// 	{id:3, name: "book 2"}
// ];

// app.get('/api/books/:id',(req,res) => {	
// 	// Prferably use let if you want variable that you can reset later else const
// 	let book = books.find(b=> b.id=== parseInt(req.params.id));
	
// 	if(!book) res.status(404).send('Book with given id does not exist');
// 	res.send(book);
// });

// app.listen(3000,()=>console.log('listening on port 3000'));


// Environment Variables

// const express = require('express');
// const app=express();

// app.get('/',(req,res) => {
// 	res.send('Hello World');
// });

// app.get('/api/books',(req,res) => {
// 	res.send(["Book 1","Book 2","Book3"]);
// });

// const port = process.env.PORT || 3000
// app.listen(port,()=>console.log(`listening on port ${port}`));


// Route Parameters

// const express = require('express');
// const app=express();

// app.get('/api/books/:id',(req,res) => {	
// 	res.send(req.params.id);
// });

// //You can have multiple parameter in a route
// app.get('/api/books/:year/:month',(req,res) => {	
// 	res.send(req.params);
// });

// //Reading Query parameter
// app.get('/api/book',(req,res) => {	
// 	res.send(req.query);
// });

// const port = process.env.PORT || 3000
// app.listen(port,()=>console.log(`listening on port ${port}`));


// Handling GET request

// const express = require('express');
// const app=express();

// const books =[
// 	{id:1, name: "book 1"},
// 	{id:2, name: "book 2"},
// 	{id:3, name: "book 2"}
// ];

// app.get('/',(req,res) => {
// 	res.send('Hello World');
// });

// app.get('/api/books',(req,res) => {
// 	res.send(books);
// });

// app.get('/api/books/:id',(req,res) => {	
// 	// Prferably use let if you want variable that you can reset 	   later else const
// 	let book = books.find(b=> b.id=== parseInt(req.params.id));
	
// 	if(!book) res.status(404).send('Book with given id does not exist');
// 	res.send(book);
// });

// const port = process.env.PORT || 3000
// app.listen(port,()=>console.log(`listening on port ${port}`));


// Handling POST request and test using POSTMAN

// const express = require('express');
// const bodyParser = require("body-parser");

// const app=express();

// // Create application/x-www-form-urlencoded parser middleware
// app.use(express.json());

// const books =[
// 	{id:1, name: "book 1"},
// 	{id:2, name: "book 2"},
// 	{id:3, name: "book 2"}
// ];

// app.get('/',(req,res) => {
// 	res.send('Hello World');
//     res.end();
// });

// app.get('/api/books',(req,res) => {
// 	res.send(books);
//     res.end();
// });

// app.get('/api/books/:id',(req,res) => {	
// 	// Preferably use let if you want variable that you can reset later else const
// 	let book = books.find(b=> b.id=== parseInt(req.params.id));
	
// 	if(!book) res.status(404).send('Book with given id does not exist');
// 	res.send(book);

//     res.end();
// });

// app.post('/api/books',(req,res)=>{
// 	const book={
// 		id: books.length +1,
// 		name: req.body.name
// 	};
// 	books.push(book);
// 	res.send(book);
//     res.end();
// });


// const port = process.env.PORT || 3000
// app.listen(port,()=>console.log(`listening on port ${port}`));


// POST request from UI 

// var express = require('express');  
// var app = express();  
// var bodyParser = require('body-parser');  
// // Create application/x-www-form-urlencoded parser  
// var urlencodedParser = bodyParser.urlencoded({ extended: true }); 
// app.use(express.static('public')); 

// const books =[
// 	{id:1, name: "book 1"},
// 	{id:2, name: "book 2"},
// 	{id:3, name: "book 2"}
// ];
  
// app.post('/api/books', urlencodedParser, function (req, res) {  
//    // Prepare output in JSON format  
//    response = {  
//         id:req.body.id,//books.length +1,  
//         name:req.body.name  
//    };  
//    console.log(response);  
//    res.end(JSON.stringify(response));  
// });  
// var server = app.listen(8000, function () {  
//   var host = server.address().address  
//   var port = server.address().port  
//   console.log("Example app listening at http://%s:%s", host, port)  
// });


// Input Validation

// const express = require('express');
// const bodyParser = require("body-parser");

// const app=express();

// // Create parser middleware
// app.use(express.json());

// const books =[
// 	{id:1, name: "book 1"},
// 	{id:2, name: "book 2"},
// 	{id:3, name: "book 2"}
// ];

// app.get('/',(req,res) => {
// 	res.send('Hello World');
//     res.end();
// });

// app.get('/api/books',(req,res) => {
// 	res.send(books);
//     res.end();
// });

// app.get('/api/books/:id',(req,res) => {	
// 	// Preferably use let if you want variable that you can reset later else const
// 	let book = books.find(b=> b.id=== parseInt(req.params.id));
	
// 	if(!book) res.status(404).send('Book with given id does not exist');
// 	res.send(book);

//     res.end();
// });

// // Refactored POST method
// app.post('/api/books',(req,res)=>{

// 	if(!req.body.name || req.body.name.length < 3)
// 	{
// 		res.status(400).send('Name is required and should have atleast 3 characters');
// 		return;
// 	}
// 	const book={
// 		id: books.length +1,
// 		name: req.body.name
// 	};
// 	books.push(book);
// 	res.send(book);
//     res.end();
// });


// const port = process.env.PORT || 3000
// app.listen(port,()=>console.log(`listening on port ${port}`));



// Using Joi for Input Validation

// const express = require('express');
// const app=express();
// const Joi=require('joi'); // It returns a class

// app.use(express.json());

// const books =[
// 	{id:1, name: "book 1"},
// 	{id:2, name: "book 2"},
// 	{id:3, name: "book 2"}
// ];

// app.get('/',(req,res) => {
// 	res.send('Hello World');
// });

// app.get('/api/books',(req,res) => {
// 	res.send(books);
// });

// app.get('/api/books/:id',(req,res) => {	
// 	// Prferably use let if you want variable that you can reset 	   later else const
// 	let book = books.find(b=> b.id=== parseInt(req.params.id));
	
// 	if(!book) res.status(404).send('Book with given id does not exist');
// 	res.send(book);
// });

// app.post('/api/books',(req,res)=>{

// 	const schema=Joi.object({
// 		name: Joi.string().min(3).required()
// 	});
//     var result = schema.validate(req.body);

// 	console.log(result);
	
// 	//if(!req.body.name || req.body.name.length < 3) -- insted of this statement we can write
// 	if(result.error)
// 	{
// 		//res.status(400).send(result.error);
// 		//You can get a single message using
// 		res.status(400).send(result.error.details[0].message);
// 		return;
// 	}
// 	const book={
// 		id: books.length +1,
// 		name: req.body.name
// 	};
// 	books.push(book);
// 	res.send(book);
// });

// const port = process.env.PORT || 3000
// app.listen(port,()=>console.log(`listening on port ${port}`));


//Handling PUT request

// const express = require('express');
// const app=express();
// const Joi=require('joi'); // It returns a class

// app.use(express.json());

// const books =[
// 	{id:1, name: "book 1"},
// 	{id:2, name: "book 2"},
// 	{id:3, name: "book 2"}
// ];

// app.get('/',(req,res) => {
// 	res.send('Hello World');
// });

// app.get('/api/books',(req,res) => {
// 	res.send(books);
// });

// app.get('/api/books/:id',(req,res) => {	
// 	// Prferably use let if you want variable that you can reset 	   later else const
// 	let book = books.find(b=> b.id=== parseInt(req.params.id));
	
// 	if(!book) res.status(404).send('Book with given id does not exist');
// 	res.send(book);
// });

// app.post('/api/books',(req,res)=>{

// 	const schema=Joi.object({
// 		name: Joi.string().min(3).required()
// 	});
//     var result = schema.validate(req.body);

// 	console.log(result);
	
// 	//if(!req.body.name || req.body.name.length < 3) -- insted of this statement we can write
// 	if(result.error)
// 	{
// 		//res.status(400).send(result.error);
// 		//You can get a single message using
// 		res.status(400).send(result.error.details[0].message);
// 		return;
// 	}
// 	const book={
// 		id: books.length +1,
// 		name: req.body.name
// 	};
// 	books.push(book);
// 	res.send(book);
// });

// app.put('/api/books/:id',(req,res)=>{
// 	//Look up the books
// 	//If not existing return 404
// 	let book = books.find(b=> b.id=== parseInt(req.params.id));
	
// 	if(!book) res.status(404).send('Book with given id does not exist');

// 	//Validate
// 	// If invalid rturn 400 - bad request
// 	const schema=Joi.object({
// 		name: Joi.string().min(3).required()
// 	});

//     var result = schema.validate(req.body);
	
// 	if(result.error)
// 	{
// 		res.status(400).send(result.error.details[0].message);
// 		return;
// 	}

// 	//Update Books
// 	book.name =req.body.name;
	
// 	//Return the updated book
//     res.send(books);
// });

// const port = process.env.PORT || 3000
// app.listen(port,()=>console.log(`listening on port ${port}`));



//Handling Delete request

// const express = require('express');
// const app=express();
// const Joi=require('joi'); // It returns a class

// app.use(express.json());

// const books =[
// 	{id:1, name: "book 1"},
// 	{id:2, name: "book 2"},
// 	{id:3, name: "book 2"}
// ];

// app.get('/',(req,res) => {
// 	res.send('Hello World');
// });

// app.get('/api/books',(req,res) => {
// 	res.send(books);
// });

// app.get('/api/books/:id',(req,res) => {	
// 	// Prferably use let if you want variable that you can reset 	   later else const
// 	let book = books.find(b=> b.id=== parseInt(req.params.id));
	
// 	if(!book) res.status(404).send('Book with given id does not exist');
// 	res.send(book);
// });

// app.post('/api/books',(req,res)=>{

// 	const schema=Joi.object({
// 		name: Joi.string().min(3).required()
// 	});
//     var result = schema.validate(req.body);

// 	console.log(result);
	
// 	//if(!req.body.name || req.body.name.length < 3) -- insted of this statement we can write
// 	if(result.error)
// 	{
// 		//res.status(400).send(result.error);
// 		//You can get a single message using
// 		res.status(400).send(result.error.details[0].message);
// 		return;
// 	}
// 	const book={
// 		id: books.length +1,
// 		name: req.body.name
// 	};
// 	books.push(book);
// 	res.send(book);
// });

// app.put('/api/books/:id',(req,res)=>{
// 	//Look up the books
// 	//If not existing return 404
// 	let book = books.find(b=> b.id=== parseInt(req.params.id));
	
// 	if(!book) res.status(404).send('Book with given id does not exist');

// 	//Validate
// 	// If invalid rturn 400 - bad request
// 	const schema=Joi.object({
// 		name: Joi.string().min(3).required()
// 	});

//     var result = schema.validate(req.body);
	
// 	if(result.error)
// 	{
// 		res.status(400).send(result.error.details[0].message);
// 		return;
// 	}

// 	//Update Books
// 	book.name =req.body.name;
	
// 	//Return the updated book
//     res.send(books);
// });

// app.delete('/api/books/:id',(req,res)=>{
// 	//Look up the books
// 	//If not existing return 404
// 	let book = books.find(b=> b.id=== parseInt(req.params.id));
	
// 	if(!book) return res.status(404).send('Book with given id does not exist');

// 	//Delete
// 	const index=books.indexOf(book);
// 	books.splice(index,1);

// 	//Return the same book
// 	res.send(book);
// });

// const port = process.env.PORT || 3000
// app.listen(port,()=>console.log(`listening on port ${port}`));