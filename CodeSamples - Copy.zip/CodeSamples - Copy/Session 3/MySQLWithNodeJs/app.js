const express = require('express');
const mysql = require('mysql');

// Create Connection
const db = mysql.createConnection({
    host     : 'localhost',
    user     : 'root',
    password : '',
    // Initially keep it commented
    database : 'nodemysql'
});

//Connect
db.connect((err)=>{
    if(err){
        throw err;
    }
    console.log('My Sql Connected..');
});

const app = express();

//Create DB
app.get('/createdb',(req,res)=>{
    let sql = 'CREATE DATABASE nodemysql';
    db.query(sql,(err,result)=>{
        if(err){
            throw err;
        }
        console.log(result);
        res.send('Database Created' + result)
    });
});

//Create Table
app.get('/createBooksTable',(req,res)=>{
    let sql = 'CREATE TABLE books(id int AUTO_INCREMENT, title VARCHAR(255), PRIMARY KEY(id))';
    db.query(sql,(err,result)=>{
        if(err) throw err;
        console.log(result);

        res.send('Books table created');
    });
});

// Insert book data 1
app.get('/addbook1',(req,res)=>{
    let book = {title:'Book 1'};
    let sql = 'INSERT INTO books SET ?';
    let query = db.query(sql,book,(err,result)=>{
        if(err) throw err;
        console.log(result);
        res.send('Book data 1 inserted');
    });
});

// Insert book data 2
app.get('/addbook2',(req,res)=>{
    let book = {title:'Book 2'};
    let sql = 'INSERT INTO books SET ?';
    let query = db.query(sql,book,(err,result)=>{
        if(err) throw err;
        console.log(result);
        res.send('Book data 2 inserted');
    });
});

// Fetch All Books
app.get('/getbooks',(req,res)=>{
  
    let sql = 'SELECT * FROM books';
    let query = db.query(sql,(err,result)=>{
        if(err) throw err;
        console.log(result);
        res.send('Books fetched');
    });
});

// Fetch Single Book
app.get('/getbook/:id',(req,res)=>{
  
    let sql =`SELECT * FROM books WHERE id = ${req.params.id}`;
    let query = db.query(sql,(err,result)=>{
        if(err) throw err;
        console.log(result);
        res.send(`Book ${req.params.id} fetched`);
    });
});

// Update book
app.get('/updatebook/:id',(req,res)=>{
    let newTitle = {title:'Updated Book 1'};    
    let sql =`UPDATE books SET ? WHERE id = ${req.params.id}`;
    let query = db.query(sql,newTitle,(err,result)=>{
        if(err) throw err;
        console.log(result);
        res.send(`Book ${req.params.id} updated`);
    });
});

// Delete book
app.get('/deletebook/:id',(req,res)=>{
 
    let sql =`DELETE FROM books WHERE id = ${req.params.id}`;
    let query = db.query(sql,(err,result)=>{
        if(err) throw err;
        console.log(result);
        res.send(`Book ${req.params.id} deleted`);
    });
});

app.listen('3000',()=>{
    console.log('Server started on port 3000');
});