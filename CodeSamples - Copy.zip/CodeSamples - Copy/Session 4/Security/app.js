const express = require('express');
const jwt = require('jsonwebtoken');

const app = express();

app.get('/', (req,res) => {
    res.json({
        message: 'Security using JWT Example'
    });
});


app.post('/api/book', verifyToken, (req,res) => {

    jwt.verify(req.token, 'SecretKey', (err,authData) => {
        if(err){
            res.sendStatus(403);
        } else {
            res.json({
                messasge: 'Book Added..',
                authData
            });
        }
    });
});

app.post('/api/login', (req,res) => {

    //Mock User object
    const book = {
        id:1,
        username: 'Sudipta',
        email: 'sudipta@gmail.com'
    };

    jwt.sign({book},'SecretKey',{expiresIn: '30s'}, (err,token) => {
        res.json({
            token
        });
    });
});

// Format of token in the header
// Authorization: Bearer <token>

function verifyToken(req,res,next){

    // Get the auth header value
    const bearerHeader =  req.headers['authorization'];
    // Check if bearer is undefined
    if(typeof bearerHeader !== 'undefined')
    {
        // Split at the space
        const bearer = bearerHeader.split(' ');
        // Get token from array
        const bearerToken = bearer[1];

        // Set the token
        req.token = bearerToken;

        // Next middlewareq
        next();

    } else {
        //Forbidden
        res.sendStatus(403);
    }

}

// var port = process.env.port || 5000;

app.listen('5000',() => {
    console.log('Server started on port 5000');
});


// Deploy the app using Azure cli. It can be downloaded from https://docs.microsoft.com/en-us/cli/azure/
// Steps: https://docs.microsoft.com/en-us/azure/developer/javascript/tutorial/tutorial-vscode-azure-cli-node/tutorial-vscode-azure-cli-node-03


// Heroku
//Install the Heroku CLI

/* 

Download and install the Heroku CLI.

If you haven't already, log in to your Heroku account and follow the prompts to create a new SSH public key.

$ heroku login
Clone the repository
Use Git to clone nodesecurityapp's source code to your local machine.

$ heroku git:clone -a nodesecurityapp
$ cd nodesecurityapp
Deploy your changes
Make some changes to the code you just cloned and deploy them to Heroku using Git.

$ git add .
$ git commit -am "make it better"
$ git push heroku master 

*/
