
// First App in Node JS
//function sayHellow(name){
    //console.log("Hello!!" + name);

    //Test that windows object is not a valid object in node
    //console.log(window);

    //Check module object
    //console.log(module);

 //  }
   
//sayHellow('Sudipta'); 


//Loading a Module
//var logger= require('./logger');
//logger =1;
// const logger= require('./logger');
// logger =1;
//console.log(logger);
//logger.log('Sudipta message');
//logger('Sudipta message');


// Path Module
//  const path=require('path');
//  var pathObj=path.parse(__filename);
//  console.log(pathObj);

//OS Module
// const os=require('os');
// var totalMemory=os.totalmem();
// var freeMemory = os.freemem();
// console.log('Total Memory: '+totalMemory);
// //ECMA 6 Syntax
// console.log(`Free Memory : ${freeMemory}`);

//File System Module
//const fs=require('fs');

// Synchronous
// const files=fs.readdirSync('./');
// console.log(files);

// Asynchronous
// fs.readdir('./',function(err,files){ // for simulating error use $ in place of './'
// 	if(err) console.log('Error',err);
// 	else console.log('Result',files);
// });

// Events
// const EventEmitter=require('events'); // the capital letter for EventEmitter shows that it is a Class
// const emitter = new EventEmitter();

// //Register a listener
// emitter.on('nameOfTheEvent',function(){
// 	console.log('Listener called');
// });

// //Raise an event
// emitter.emit('nameOfTheEvent');

// Event Arguments
// const EventEmitter=require('events'); // the capital letter for EventEmitter shows that it is a Class
// const emitter = new EventEmitter();

// //Register a listener
// emitter.on('nameOfTheEvent',function(args){
// 	console.log('Listener called with argument id : '+ args.id+' URL : ' + args.url);
// });

// //Raise an event
// emitter.emit('nameOfTheEvent',{id:1,url:'http://anbc.com'});


// Extending Event Emitter
//const EventEmitter=require('events'); 

// const Logger=require('./logger');
// const logger1=new Logger();

// logger1.on('nameOftheEvent',(arg) => {
// 	console.log('Listener called',arg);
// });

// logger1.log('message');


// HTTP module (Creating a simple Web Server)
// const http = require('http');

// const server = http.createServer((req,res) => {
// 	if(req.url==='/'){
// 		res.write('Hello');
// 		res.end();
// 	}
// }); 

// server.listen(3000);

// console.log('listening on port 3000');


// In real world
// const http = require('http');

// const server = http.createServer((req,res) => {
// 	if(req.url==='/api/test'){
//         console.log("test API hit");
// 		res.write(JSON.stringify([1,2,4]));
// 		res.end();
// 	}
// }); 

// server.listen(3000);

// console.log('listening on port 3000');