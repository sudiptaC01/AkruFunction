// Wrapper Module
//(function(exports,require,module,__filename,__dirname){

// var url ='http://abc.com/log';

// function log(message){
//   // send HTTP request
//   console.log(message);
// }

// //Exposing log as an object
// //module.exports.log=log;

// //module.exports.endpoint=url;

// //Exposing log as a function
// module.exports = log;
// //});


//Extending Event Emitter
const EventEmitter=require('events'); 

class Logger extends EventEmitter{
	log(message){
		console.log(message);
		
		this.emit('nameOftheEvent',{id:1,url:'http://'});
	}
}

module.exports=Logger;